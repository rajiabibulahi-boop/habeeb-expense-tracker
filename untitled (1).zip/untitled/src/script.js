const balance = document.getElementById("balance");
const income = document.getElementById("income");
const expense = document.getElementById("expense");

const text = document.getElementById("text");
const amount = document.getElementById("amount");
const type = document.getElementById("type");

const addBtn = document.getElementById("addBtn");
const list = document.getElementById("list");

let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

function saveTransactions() {
    localStorage.setItem("transactions", JSON.stringify(transactions));
}

function updateUI() {

    list.innerHTML = "";

    let incomeTotal = 0;
    let expenseTotal = 0;

    transactions.forEach((transaction, index) => {

        const li = document.createElement("li");

        li.innerHTML = `
            <span>${transaction.text}</span>
            <span>₦${transaction.amount}</span>
            <button onclick="deleteTransaction(${index})">❌</button>
        `;

        list.appendChild(li);

        if (transaction.type === "income") {
            incomeTotal += transaction.amount;
        } else {
            expenseTotal += transaction.amount;
        }

    });

    income.textContent = "₦" + incomeTotal.toFixed(2);
    expense.textContent = "₦" + expenseTotal.toFixed(2);

    balance.textContent =
        "₦" + (incomeTotal - expenseTotal).toFixed(2);

    saveTransactions();
}

function deleteTransaction(index) {
    transactions.splice(index, 1);
    updateUI();
}

addBtn.addEventListener("click", () => {

    const description = text.value.trim();
    const value = Number(amount.value);

    if (description === "" || value <= 0) {
        alert("Please enter a valid description and amount.");
        return;
    }

    transactions.push({
        text: description,
        amount: value,
        type: type.value
    });

    text.value = "";
    amount.value = "";

    updateUI();

});

updateUI();